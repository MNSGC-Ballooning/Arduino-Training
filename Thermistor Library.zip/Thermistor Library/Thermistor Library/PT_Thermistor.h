/************************************************
      MnSGC Ballooning PTERODACTYL Sketch
      Created by: Ashton Posey
      Date: 7/29/22
************************************************/
//Purpose: This Sketch will allow any number of Thermistors 
//         to be controlled frictionlessly

#ifndef PT_THERMISTOR_H
#define PT_THERMISTOR_H
#include <Arduino.h>

/***********************************************************************************************************************************************
Class Definition
************************************************************************************************************************************************/
class Thermistor{
  public:
    Thermistor(int pin);
    bool begin(int analogResolutionBits);
    bool updateStatus();
    bool getStatus();
    float getTempC();
    float getTempF();
    void update();
    
  private:
    int _pin;
    int _analogResolutionBits;
    float adcMax; // The maximum adc value given to the thermistor
    float A = 0.001125308852122;   // A, B, and C are constants used for a 10k resistor and 10k thermistor for the steinhart-hart equation
    float B = 0.000234711863267;
    float C = 0.000000085663516; 
    float R1 = 10000; // 10k Ω resistor
    float Tinv;
    float adcVal;
    float logR;
    float T; // these three variables are used for the calculation from adc value to temperature
    float currentTempC = 999; // The current temperature in Celcius
    float currentTempF = 999; // The current temperature in Fahrenheit
    bool _status = false;
};

#endif